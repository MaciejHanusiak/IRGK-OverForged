using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelMenu : MonoBehaviour
{
    public Button[] buttons;
    public GameObject levelButtons;
    private void Awake()
    {
        ButtonsToArray();
        int unlockedLevel = Mathf.Min(PlayerPrefs.GetInt("UnlockedLevel", 1), buttons.Length);
        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].interactable = false;
        }
        for (int i = 0; i < unlockedLevel; i++)
        {
            buttons[i].interactable = true;
        }
    }
    public void OpenLevel(int levelId)
    {
        string levelName = "Level " + levelId; 
        SceneManager.LoadScene(levelName);
    }
    public void OpenTutorialLevel(string levelName)
    {
        SceneManager.LoadScene(levelName);
    }
    void ButtonsToArray()
    {
        int childCount = levelButtons.transform.childCount;
        buttons = new Button[childCount];
        for (int i = 0; i < childCount; i++)
        {
            buttons[i] = levelButtons.transform.GetChild(i).GetComponent<Button>();
        }
    }
}
